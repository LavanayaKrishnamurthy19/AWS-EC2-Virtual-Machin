# Create and Display a Basic Virtual Machine on AWS Cloud

## Aim
To create, launch, connect to, and verify a basic virtual machine using Amazon EC2 on AWS Cloud.

## Tools and technologies
- Amazon Web Services (AWS)
- Amazon EC2
- Amazon Linux 2023 or Ubuntu Server 24.04 LTS
- Linux commands
- Git and GitHub for documentation and version control

## Procedure

### Step 1: Log in to the AWS Management Console
1. Open https://console.aws.amazon.com/
2. Sign in using your AWS account credentials.
3. The AWS Management Console dashboard appears after successful login.

### Step 2: Open the EC2 Dashboard
1. Search for **EC2** in the AWS search bar.
2. Select EC2 from the services list.
3. The EC2 Dashboard opens.

### Step 3: Launch a New EC2 Instance
1. Click **Launch instance**.
2. Set the instance name to `MyFirstEC2`.
3. Choose **Amazon Linux 2023** or **Ubuntu Server 24.04 LTS**.
4. Choose an instance type available to your account and region, such as `t2.micro` or another suitable small instance.

> Pricing and Free Tier eligibility depend on your AWS account, region, instance type, and current AWS offers. Check the pricing shown in your account before launching.

### Step 4: Create a Key Pair
1. Under **Key pair (login)**, choose **Create new key pair**.
2. Name it `MyKeyPair`.
3. Choose RSA and `.pem` format.
4. Create the key pair and save the downloaded file securely.

**Security:** Never upload your `.pem` private key to GitHub or share it with anyone.

### Step 5: Configure Network Settings
1. Under **Network settings**, choose **Edit**.
2. Allow SSH traffic on port 22, with the source set to **My IP** if you plan to use SSH from your computer.
3. If you want to host a webpage, optionally allow HTTP traffic on port 80.
4. Do not expose SSH to `0.0.0.0/0`.

### Step 6: Configure Storage
Keep the default storage or choose an appropriate size, such as 8–10 GB General Purpose SSD, if available. Review any storage charges.

### Step 7: Launch the Instance
1. Review the configuration.
2. Click **Launch instance**.
3. Wait for AWS to confirm that the instance has launched.

### Step 8: Verify Instance Status
1. Open **View all instances**.
2. Select `MyFirstEC2`.
3. Confirm that the instance state is **Running**.
4. Wait until the status checks show **2/2 checks passed**.

### Step 9: Connect to the EC2 Instance
1. Select the instance.
2. Click **Connect**.
3. Choose **EC2 Instance Connect**, if available for your instance and network configuration.
4. Click **Connect** to open the browser-based terminal.

If EC2 Instance Connect is unavailable, check the AWS troubleshooting guide or use SSH with your downloaded key pair.

### Step 10: Verify the Connection

Run:

```bash
hostname
whoami
```

Example output (your hostname and username may differ):

```text
ip-172-31-20-100
ec2-user
```

For Ubuntu, the default login username is commonly `ubuntu`.

### Step 11: Update the Operating System

For Amazon Linux 2023:

```bash
sudo dnf update -y
```

For Ubuntu:

```bash
sudo apt update && sudo apt upgrade -y
```

### Step 12: Create a Test File

```bash
echo "AWS EC2 Instance Working Successfully" > test.txt
cat test.txt
```

Expected output:

```text
AWS EC2 Instance Working Successfully
```

### Step 13: Verify Internet Connectivity

```bash
ping -c 4 google.com
```

If ping fails, check the instance's internet route, subnet, security/network configuration, and DNS. Some networks may block ICMP traffic, so a failed ping alone does not prove that the instance has no internet access.

### Step 14: Stop the Instance
1. Return to the EC2 Instances page.
2. Select `MyFirstEC2`.
3. Choose **Instance state → Stop instance**.
4. Confirm the action.

A stopped EBS-backed instance can still incur storage charges. Public IPv4 address charges may also apply depending on current AWS pricing.

### Step 15: Terminate the Instance (Optional)
1. Select the instance.
2. Choose **Instance state → Terminate instance**.
3. Confirm only when you are sure you no longer need it.

Termination is normally irreversible. Check whether any data or storage volumes need to be retained first.

## Sample output

The following is an example of the expected results. Replace it with your own screenshots and actual output after completing the practical.

```text
EC2 instance created successfully.
Instance state: Running
Status checks: 2/2 checks passed
Connection: Established using EC2 Instance Connect
Hostname: (your instance hostname)
User: ec2-user (Amazon Linux) or ubuntu (Ubuntu)
Test file: Created successfully
Test file content: AWS EC2 Instance Working Successfully
```

## Result

A basic virtual machine (Amazon EC2 instance) was created and deployed on AWS Cloud. The instance was connected to using EC2 Instance Connect, and its operation was verified using Linux commands and a test file. The objective of launching and managing a virtual machine on AWS Cloud was achieved.

## Screenshots

Add your own practical screenshots to the `screenshots` folder. Suggested screenshots:

1. AWS Management Console dashboard
2. EC2 Dashboard
3. Launch instance configuration
4. Instance running with 2/2 status checks passed
5. EC2 Instance Connect terminal
6. `hostname` and `whoami` command output
7. Test file creation and verification
8. Stop or terminate confirmation (if performed)

## GitHub upload instructions

1. Sign in to https://github.com/
2. Click **New repository**.
3. Enter the repository name: `AWS-EC2-Virtual-Machine`.
4. Select Public or Private as appropriate.
5. Click **Create repository**.
6. Choose **Add file → Upload files**.
7. Upload `README.md`, `commands.txt`, `sample-output.txt`, and your screenshots.
8. Click **Commit changes**.

Alternatively, use Git:

```bash
git init
git add .
git commit -m "Add AWS EC2 virtual machine practical"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/AWS-EC2-Virtual-Machine.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your GitHub username.

## Important security reminders
- Never commit AWS passwords, access keys, secret keys, `.pem` files, or other credentials.
- Keep SSH access restricted to your own IP address.
- Review AWS pricing before launching resources.
- Stop or terminate resources when you finish, and verify that no unwanted billable resources remain.
